import syntaxtree.*;
import visitor.*;
import java.util.*;

public class P2 {
   public static void main(String [] args) {
      try {
         Node root = new MiniJavaParser(System.in).Goal();
         //System.out.println("Program parsed successfully");
         HashMap<String,HashMap<String,String>> Scopes = (HashMap<String,HashMap<String,String>>)root.accept(new Hasher(),null); // Your assignment part is invoked here.
         /*
            Do Overriding Checking Here
         */
         root.accept(new TypeChecker(),Scopes); // Your assignment part is invoked here.
         //System.out.println(Scopes);
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



