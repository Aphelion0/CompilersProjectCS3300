import java.util.*;

public class JavaGenerics
{
    private Map<String,List> map;

    public void jriat()
    {
        int i = 1 >>> 4;
        int j = 1 >> 4;
	boolean b = 1 > 4;
    }
}
